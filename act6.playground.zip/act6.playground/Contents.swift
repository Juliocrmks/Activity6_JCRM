import UIKit
import CoreGraphics


// Operadores

let a  = 5
let b  = 2

infix operator ||>
func ||> (left:Int, right:Int)->Int{
    let a = (Double)(left)
    let b = (Double)(right)
    return (Int) (pow(a,b))
}

a||>b

infix operator |>
func |> (a:[Int], f:([Int])->[Int] )-> [Int]{
    return f(a)
}
func arrange(dato:[Int])->[Int]{
    var arr = dato
    arr.sort()
    return arr
}

let arr = [2,5,3,4]
arr|>arrange

// Subscript
let array = [2,3,4,5];
class SubScript{
    var valores:[Int]
    init(v:[Int])
    
    {
        self.valores = v
    }
    subscript(idx:Int)->Int{
        get{
            return valores[idx] * 2
        }
        set(nuevoValor){
            valores[idx] = nuevoValor * 2
        }
    }
}

let v1 = SubScript(v: array)

v1[1]

struct CGPoint{
    let point :Int
    
    init(point:Int){
        self.point = point
    }
}

class Enemy {
    
    let xAxis :CGPoint
    let yAxis: CGPoint
    var position:[CGPoint]
    init(xAxis:CGPoint, yAxis:CGPoint){
        self.xAxis = xAxis
        self.yAxis = yAxis
        self.position = [xAxis,yAxis]
    }
    subscript(xAxis:CGPoint, yAxis:CGPoint)-> [CGPoint]{
        get{
            return position
        }
        set {
            position = [xAxis,yAxis]
        }
    }
}
let x = CGPoint(point:5)
let y = CGPoint(point:10)

let villian = Enemy(xAxis: x, yAxis: y)
villian.position



// Control de Errores

let coll = ["A":1, "B":2,"C":3]

func ExisteValor(index:String){
    guard let existe = coll[index] else{
        print("No existe")
        return
    }
    print("Si existe con el valor de : \(existe)")
}
ExisteValor(index: "B")
coll["F"]
ExisteValor(index: "F")
